"""AIRA Checkers"""
